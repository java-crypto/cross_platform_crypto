using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Konscious.Security.Cryptography;
// https://github.com/kmaragon/Konscious.Security.Cryptography

public class Program {
	public static void Main() {
		Console.WriteLine("Generate a 32 byte long AES key with Argon2id");

		var password = "secret password";
    
    byte[] salt = GenerateFixedSalt16Byte();

    Console.WriteLine("Creating hash for password " + password );
	  var argon2id = new Argon2id(Encoding.UTF8.GetBytes(password));
	  argon2id.Salt = salt;
    argon2id.DegreeOfParallelism = 1; // four cores
    argon2id.Iterations = 20;
    argon2id.MemorySize = 1024 * 8; // 8 MB	
	  byte[] hashBytes = 	argon2id.GetBytes(32);
	  Console.WriteLine("argon2id: " + argon2id);	
	  Console.WriteLine("argon2id: " + BytesToHex(hashBytes));
    
 
  }

  static byte[] GenerateFixedSalt16Byte() {
    // ### security warning - never use this in production ###
    byte[] salt = new byte[16];
    return salt;
  }

    static string BytesToHex(byte[] ba) {
    StringBuilder hex = new StringBuilder(ba.Length * 2);
    foreach (byte b in ba)
      hex.AppendFormat("{0:x2}", b);
    return hex.ToString();
  }
}